package com.example.asm2java202;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Asm2Java202ApplicationTests {

    @Test
    void contextLoads() {
    }

}
